
symmetric {
    auto.startup = false
    db.spring.bean.name='parent.dataSource'
    auto.insert.registration.svr.if.not.found=true
    web.base.servlet.path='/sync'
    sync.url = 'http://localhost:8080/symmetric-grails/sync'
    external.id = 'setme'
    group.id = 'setme'    
}

environments {
    root {
        symmetric {
            auto.startup = true
            sync.url = 'http://localhost:8080/symmetric-grails/sync'
            external.id = 'root'
            group.id = 'root'     
            auto.registration=true            
            auto.reload=true
            auto.config.registration.svr.sql.script='/test-root-config.sql'
        }
    }
    client {
        symmetric {
            auto.startup = true
            sync.url = 'http://localhost:8090/symmetric-grails/sync'
            external.id = 'client'
            group.id = 'client'
            registration.url='http://localhost:8080/symmetric-grails/sync'
        }
    }    
}